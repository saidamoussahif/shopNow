<?php


 session_start();

  if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $_SESSION["user"]="admin";
  }
  if(empty($_SESSION["user"])){
    require 'component/login.php';
  }else{
    require 'component/adminUserface.php';
    
  }
 



?>