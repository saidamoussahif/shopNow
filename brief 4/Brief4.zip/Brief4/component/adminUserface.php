<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sass/empolyee.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;1,100;1,300&display=swap" rel="stylesheet">
    <title>ShopNow</title>
</head>
<body>
    
     <header>
        <h3>ShopNow</h3>
        <div class="emp-pro">
            <img src="images/user-icon.svg" alt="" srcset="">
            <span class="emp-name">
                Moussahif saida
                <br>
              moussahifsaida@gmail.com
            </span>
            
           <a href="component/logout.php"> <img src="images/poweroff.svg" class="logout" alt="" srcset=""></a>
        </div>
     </header>

    
        <nav class='aside'>
            <div class="logo-container">
                <h1><img src="images/logo.svg" alt="" srcset=""></h1>
            </div>
            <div class="nav-list">
            <ul>
                <li><img src="images/dashboard.svg" alt="" srcset=""><a href="?dashboard">Dashboard</a></li>
                <li><img src="images/product.svg" alt="" srcset=""><a href="?poduct">Products</a></li>
                <li><img src="images/addproduct.svg" alt="" srcset=""><a href="?addproduct">AddProduct</a></li>
                <li><img src="images/category.svg" alt="" srcset=""><a href="?categorie">Categories</a></li>
            </ul>
            </div>
            <footer class="footer">
                <div class="img-logout">
                    <a href="component/logout.php"> <img src="images/logout.svg" alt="" srcset=""></a>
                    <span>Logout</span>
                </div>
                <h4>© 2022 ShopNow. All rights reserved</h4>
            </footer>
        </nav>
        
        <div class="conten">
        <div class="main">

        <?php 
        
            if(isset($_GET["update"]) && isset($_GET["poduct"])){
                require 'component/updateproduct.php';
            }
            elseif(isset($_GET["dashboard"])){
                require 'component/dashboard.php'; 
            }elseif(isset($_GET["poduct"])){
                require 'component/products.php'; 
            }elseif(isset($_GET["addproduct"])){
                require 'component/addproduct.php'; 
            }elseif(isset($_GET["categorie"])){
                require 'component/categoriess.php'; 
            }else{
                require 'component/dashboard.php'; 
            }
        
        ?>
  
        </div>
    </div>

   

</body>
</html>