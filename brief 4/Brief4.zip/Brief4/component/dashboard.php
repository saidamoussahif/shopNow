



<div class="dashboard">
    <div>Products <br> 13</div>
    <div>Categories <br> 54</div>
    <div>Products with low quantity <br> RELEX <br> 04</div>
</div>



















