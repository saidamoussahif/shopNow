


<div class="title-container">
    <h2 class="product-title">Products</h2>
</div>


<table>
    <tr>
        <th>Name</th>
        <th>Description</th>
        <th>Category</th>
        <th>Image</th>
        <th>Stock</th>
        <th>Price</th>
        <th colspan="2">Action</th>
    </tr>
    <tr>
        <td>Ablu</td>
        <td>Silver Round and gray</td>
        <td>Female</td>
        <td><img class="pic" src="images/1.svg" alt="" srcset=""></td>
        <td>3</td>
        <td>185$</td>
        <td><a href="?poduct&update"><img src="images/update.svg" alt="" srcset=""></a></td>
        <td><img src="images/delete.svg" alt="" srcset=""></td>
    </tr>
    <tr>
        <td>Hamilton</td>
        <td>Blue and silver</td>
        <td>Female</td>
        <td><img class="pic" src="images/2.svg" alt="" srcset=""></td>
        <td>5</td>
        <td>150$</td>
        <td><a href="?poduct&update"><img src="images/update.svg" alt="" srcset=""></a></td>
        <td><img src="images/delete.svg" alt="" srcset=""></td>
    </tr>
    <tr>
        <td>Timex</td>
        <td>Silver and gold</td>
        <td>Male</td>
        <td><img class="pic" src="images/4.svg" alt="" srcset=""></td>
        <td>6</td>
        <td>175$</td>
        <td><a href="?poduct&update"><img src="images/update.svg" alt="" srcset=""></a></td>
        <td><img src="images/delete.svg" alt="" srcset=""></td>
    </tr>
    <tr>
        <td>Casio</td>
        <td>Casio Chronograph Watch</td>
        <td>Male</td>
        <td><img class="pic" src="images/12.svg" alt="" srcset=""></td>
        <td>10</td>
        <td>180$</td>
        <td><a href="?poduct&update"><img src="images/update.svg" alt="" srcset=""></a></td>
        <td><img src="images/delete.svg" alt="" srcset=""></td>
    </tr>
    <tr>
        <td>Watch</td>
        <td>Silver Linked Bracelet Silver and Black</td>
        <td>Male</td>
        <td><img class="pic" src="images/watch.svg" alt="" srcset=""></td>
        <td>9</td>
        <td>200$</td>
        <td><a href="?poduct&update"><img src="images/update.svg" alt="" srcset=""></a></td>
        <td><img src="images/delete.svg" alt="" srcset=""></td>
    </tr>
</table>