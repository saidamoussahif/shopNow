


<div class="title-container">
    <h3 class="product-title">Categories</h3>

</div>

<table style="border:1px solid gray">
    <tr>
        <th style="border:1px solid gray">Number</th>
        <th style="border:1px solid gray">Category</th>
    </tr>
    <tr>
        <td style="border:1px solid gray">1</td>
        <td style="border:1px solid gray">Female</td>
    </tr>

    <tr>
        <td style="border:1px solid gray">2</td>
        <td style="border:1px solid gray">Male</td>
    </tr>
 
</table>