

<div class="form-container">
    <form action="" method="post" class="form-add">
        <div class="group-input">
                <div  class="info">
                    <label for="">Name</label><br>
                    <input type="text" placeholder="Enter the name" style="padding:20px 10px;">
                </div>
                <div  class="info">
                    <label for="">Stock</label><br>
                    <input type="text" placeholder="Enter the stock" style="padding:20px 10px;">
                </div>
        </div>
        <br><br>
        <div class="group-input">
                <div  class="info">
                        <label for="">Price</label><br>
                        <input type="text" placeholder="Enter the price" style="padding:20px 10px;">
                </div>
                <div  class="info">
                    <label for="">Category</label><br>
                    <select name="" id="" style="padding:20px 10px;">
                        <option value="">Female</option>
                        <option value="">Male</option>
                    </select>
                </div>
        </div>
        <br><br>
        <div   class="group-input">
             <label for="">Description<br>
             <input type="text" placeholder="Enter the description" style="padding:20px 10px;">
             </label>
        </div  class="info">
        <br><br>
        <div   class="group-input">
            <label for="">Image<br>
            <input type="text" placeholder="Choose image" style="padding:20px 10px;">
            </label>
        </div>
        <br><br>
        <div   class="group-input">
            <input type="button" class="submit" value="Add">
        </div>
    </form>


</div>





