
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sass/empolyee.css">
    <title>Document</title>
</head>
<body>
    

    <div class="form-login">
        <h1><img src="images/logo.svg" alt="" srcset=""></h1>
        <form action="" method="post">
            <div>
                <label for="email">Email</label>
                <input type="text" placeholder="email" required>
            </div>

            <div>
                <label for="email">Password</label>
               <input type="password" placeholder="password" required>
            </div>

            <div class="btn-container">
               <input type="submit" class="submit" value="Confim">
            </div>

        </form>
    </div>

</body>
</html>

 











